package com.example.minhatrip;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Spinner spinnerFrom;
    private Spinner spinnerTo;
    private TextView lblDistance;
    private TextView lblCost;
    private TextView lblConsumption;
    private MinhatripDAO dao;

    private static final double PRICE_PER_LITER = 6.0; // Preço do litro de gasolina
    private static final double CONSUMPTION = 8.0; // Consumo em L/100km

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa os componentes da interface
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        lblDistance = findViewById(R.id.lblDistance);
        lblCost = findViewById(R.id.lblCost);
        lblConsumption = findViewById(R.id.lblConsumption);
        Button buttonCalculate = findViewById(R.id.buttonCalculate);

        // Inicializa o DAO
        dao = new MinhatripDAO();

        // Configura os Spinners
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.cities_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrom.setAdapter(adapter);
        spinnerTo.setAdapter(adapter);

        // Configura o listener do botão
        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
            }
        });
    }

    private void calculate() {
        String fromCity = spinnerFrom.getSelectedItem().toString();
        String toCity = spinnerTo.getSelectedItem().toString();

        // Verifica se as cidades selecionadas são iguais
        if (fromCity.equals(toCity)) {
            lblDistance.setText("Cidades iguais! Escolha cidades diferentes.");
            clearResults();
            return;
        }

        double distance = dao.getDistanceFromMap(fromCity, toCity);

        // Verifica se houve erro ao obter a distância
        if (distance == -1) {
            lblDistance.setText("Erro ao obter a distância.");
            clearResults();
            return;
        }

        // Calcula o custo e o consumo
        double cost = (distance / 100) * PRICE_PER_LITER * CONSUMPTION;
        double consumption = (cost / PRICE_PER_LITER) * 100 / distance;

        // Exibe os resultados
        lblDistance.setText(String.format("Distância: %.2f km", distance));
        lblCost.setText(String.format("Custo: R$ %.2f", cost));
        lblConsumption.setText(String.format("Consumo: %.2f L/100km", consumption));
    }

    private void clearResults() {
        lblCost.setText("");
        lblConsumption.setText("");
    }
}
