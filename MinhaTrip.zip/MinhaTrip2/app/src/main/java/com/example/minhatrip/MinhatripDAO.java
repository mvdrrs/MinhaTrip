package com.example.minhatrip;

import java.util.HashMap;
import java.util.Map;

public class MinhatripDAO {

    private Map<String, Map<String, Double>> distances;

    public MinhatripDAO() {
        distances = new HashMap<>();

        // Exemplo de distâncias (em km)
        addDistance("SALVADOR", "BRASILIA", 1425);
        addDistance("SALVADOR", "SAO PAULO", 1950);
        addDistance("SALVADOR", "RIO DE JANEIRO", 1030);
        addDistance("BRASILIA", "SAO PAULO", 1000);
        addDistance("BRASILIA", "RIO DE JANEIRO", 1140);
        addDistance("SAO PAULO", "RIO DE JANEIRO", 430);
        addDistance("BELO HORIZONTE", "SAO PAULO", 590);
        addDistance("GOIANIA", "BRASILIA", 209);
        addDistance("JOAO PESSOA", "MACEIO", 110);
        addDistance("FLORIANOPOLIS", "SAO PAULO", 700);
        // Adicione outras distâncias conforme necessário
    }

    private void addDistance(String city1, String city2, double distance) {
        distances.putIfAbsent(city1, new HashMap<>());
        distances.get(city1).put(city2, distance);
        distances.putIfAbsent(city2, new HashMap<>());
        distances.get(city2).put(city1, distance);
    }

    public double getDistanceFromMap(String from, String to) {
        if (distances.containsKey(from) && distances.get(from).containsKey(to)) {
            return distances.get(from).get(to);
        }
        return -1; // Se a distância não for encontrada
    }
}
